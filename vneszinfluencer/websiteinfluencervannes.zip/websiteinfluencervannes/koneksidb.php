<?php

$databaseHost = 'localhost';
$databaseName = 'websiteinfluencervannes';
$databaseUsername = 'root';
$databasePassword = '';
 
$db = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
 ?>