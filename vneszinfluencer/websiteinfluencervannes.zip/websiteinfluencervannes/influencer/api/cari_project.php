<?php

  include '../../koneksidb.php';

  $sql = "SELECT * FROM tabel_project WHERE nama_project LIKE '%".$_POST['cari_project']."%' ORDER by id DESC LIMIT 10";
  $query = mysqli_query($db, $sql);

    $list_data = array();
    while($data = mysqli_fetch_assoc($query)){
        $list_data[] = array(
            'id' => $data['id'],
            'waktu_posting'=> $data['waktu_posting'],
            'logo_brand'=> $data['logo_brand'],
            'nama_brand'=> $data['nama_brand'],
            'nama_project'=> $data['nama_project'],
            'kategori'=> $data['kategori'],
            'kriteria_project'=> $data['kriteria_project'],
            'gaji_influencer'=> 'Rp '.number_format($data['gaji_influencer'], 0, ',', '.'),
        );
    }
    echo json_encode(array(
        'data' => $list_data
    ));
  
  ?>